from django.apps import AppConfig


class CourseschedulesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "courseschedules"
